import * as React from "react";
import { Stack, useRouter } from "expo-router";
import {
  Alert,
  StyleSheet,
  Switch,
  TouchableHighlight,
  View,
} from "react-native";

import * as ExpoMediaLibrary from "expo-media-library";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Camera, CameraPermissionStatus } from "react-native-vision-camera";
import { Ionicons } from "@expo/vector-icons";

const ICON_SIZE = 26;

// Componente principal da tela de permissões
export default function PermissionsScreen() {
  // hook de navegação (expo-router)
  const router = useRouter();

  // estados para armazenar o status das permissões da câmera e do microfone
  const [cameraPermissionStatus, setCameraPermissionStatus] =
    React.useState<CameraPermissionStatus>("not-determined");
  const [microphonePermissionStatus, setMicrophonePermissionStatus] =
    React.useState<CameraPermissionStatus>("not-determined");

  // hook da biblioteca de mídia do Expo para verificar/solicitar permissão
  const [mediaLibraryPermission, requestMediaLibraryPermission] =
    ExpoMediaLibrary.usePermissions();

  // Função para solicitar permissão do microfone
  const requestMicrophonePermission = async () => {
    // solicita permissão ao módulo de câmera (microfone)
    const permission = await Camera.requestMicrophonePermission();

    // atualiza o estado local com o resultado
    setMicrophonePermissionStatus(permission);
  };

  // Função para solicitar permissão da câmera
  const requestCameraPermission = async () => {
    // solicita permissão ao módulo de câmera
    const permission = await Camera.requestCameraPermission();

    // atualiza o estado local com o resultado
    setCameraPermissionStatus(permission);
  };

  // Lida com o botão de continuar: só prossegue se todas as permissões estiverem concedidas
  const handleContinue = () => {
    if (
      cameraPermissionStatus === "granted" &&
      microphonePermissionStatus === "granted" &&
      mediaLibraryPermission?.granted
    ) {
      // substitui a rota atual e vai para a tela principal
      router.replace("/");
    } else {
      // alerta o usuário pedindo para ativar as permissões nas configurações
      Alert.alert("Por favor, vá às configurações e ative as permissões");
    }
  };

  return (
    <>
      {/* Define o título da tela na barra de navegação */}
      <Stack.Screen options={{ title: "Permissões" }} />

      {/* Container principal com tema */}
      <ThemedView style={styles.container}>
        {/* Espaço superior */}
        <View style={styles.spacer} />

        {/* Texto explicativo sobre as permissões necessárias */}
        <ThemedText type="subtitle" style={styles.subtitle}>
          Obscura precisa de acesso a algumas permissões para funcionar corretamente.
        </ThemedText>

        <View style={styles.spacer} />

        {/* Linha indicando que as permissões abaixo são obrigatórias */}
        <View style={styles.row}>
          <Ionicons
            name="lock-closed-outline"
            color={"orange"}
            size={ICON_SIZE}
          />
          <ThemedText style={styles.footnote}>OBRIGATÓRIO</ThemedText>
        </View>

        <View style={styles.spacer} />

        {/* Bloco de permissão: Câmera */}
        <View
          style={StyleSheet.compose(styles.row, styles.permissionContainer)}
        >
          {/* Ícone da câmera */}
          <Ionicons name="camera-outline" color={"gray"} size={ICON_SIZE} />

          {/* Textos explicativos sobre a permissão de câmera */}
          <View style={styles.permissionText}>
            <ThemedText type="subtitle">Câmera</ThemedText>
            <ThemedText>Usada para tirar fotos e gravar vídeos.</ThemedText>
          </View>

          {/* Switch para solicitar/perceber a permissão de câmera */}
          <Switch
            trackColor={{ true: "orange" }}
            value={cameraPermissionStatus === "granted"}
            onChange={requestCameraPermission}
          />
        </View>

        <View style={styles.spacer} />

        {/* Bloco de permissão: Microfone */}
        <View
          style={StyleSheet.compose(styles.row, styles.permissionContainer)}
        >
          <View style={styles.row}>
            {/* Ícone do microfone */}
            <Ionicons
              name="mic-circle-outline"
              color={"gray"}
              size={ICON_SIZE}
            />

            {/* Textos explicativos sobre a permissão de microfone */}
            <View style={styles.permissionText}>
              <ThemedText type="subtitle">Microfone</ThemedText>
              <ThemedText>Usado para gravar vídeo</ThemedText>
            </View>
          </View>

          {/* Switch para solicitar/perceber a permissão do microfone */}
          <Switch
            trackColor={{ true: "orange" }}
            value={microphonePermissionStatus === "granted"}
            onChange={requestMicrophonePermission}
          />
        </View>

        <View style={styles.spacer} />

        {/* Bloco de permissão: Biblioteca (Media Library) */}
        <View
          style={StyleSheet.compose(styles.row, styles.permissionContainer)}
        >
          {/* Ícone da biblioteca */}
          <Ionicons name="library-outline" color={"gray"} size={ICON_SIZE} />

          {/* Textos explicativos sobre a permissão de biblioteca */}
          <View style={styles.permissionText}>
            <ThemedText type="subtitle">Biblioteca</ThemedText>
            <ThemedText>Usada para salvar, visualizar e mais.</ThemedText>
          </View>

          {/* Switch que solicita a permissão da biblioteca de mídia do Expo */}
          <Switch
            trackColor={{ true: "orange" }}
            value={mediaLibraryPermission?.granted}
            // @ts-ignore
            onChange={async () => await requestMediaLibraryPermission()}
          />
        </View>

        <View style={styles.spacer} />
        <View style={styles.spacer} />
        <View style={styles.spacer} />

        {/* Botão de continuar: verifica permissões e navega se tudo estiver ok */}
        <TouchableHighlight
          onPress={handleContinue}
          style={StyleSheet.compose(styles.row, styles.continueButton)}
        >
          <Ionicons
            name="arrow-forward-outline"
            color={"white"}
            size={ICON_SIZE}
          />
        </TouchableHighlight>
      </ThemedView>
    </>
  );
}

// Estilos do componente
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  subtitle: {
    textAlign: "center",
  },
  footnote: {
    fontSize: 12,
    fontWeight: "bold",
    letterSpacing: 2,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  spacer: {
    marginVertical: 8,
  },
  permissionContainer: {
    backgroundColor: "#ffffff20",
    borderRadius: 10,
    padding: 10,
    justifyContent: "space-between",
  },
  permissionText: {
    marginLeft: 10,
    flexShrink: 1,
  },
  continueButton: {
    padding: 10,
    borderWidth: 2,
    borderColor: "white",
    borderRadius: 50,
    alignSelf: "center",
  },
});
 