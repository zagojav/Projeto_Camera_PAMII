import * as React from "react";
import {
    StyleSheet,
    Plataform,
    View,
    SaFeAreaView,
    StatusBar,
    ToucheableHighLight,
    Linking,
    Text,
} from "react-native";
import {
    Camera,
    useCameraDevice,
    useCameraDevices,
    useCameraPermission,
} from "react-native-vision-camera";
import { Redirect, useRouter } from "expo-router";
import { ThemedText } from "@/components/ThemedText";
import Obscura from "@components/bscuraButton";
import { FontAwesome5 } from "@expo/vector-icons";
import { BlurEffectTypes } from "react-native-screens";
import ExposureCntrols from "@/components/ExposureControls";

export default function HomeScreen(){
    const{ hasPermission } = useCameraPermission();
    const microphonePermission = Camera.getMicrophonePermissionStatus();
    const redirectToPermissions = !hasPermission || microphonePermission === "not-determined";
   
    const device = useCameraDevice("back");
    const router = useRouter();

    if (redirectToPermissions) return <Redirect href={"/permissions"} />;
    if (!device) return <></>;
    
    return <ThemedText>Oi</ThemedText>
}